chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === "exportCookies_from_popup") {
        chrome.cookies.getAll({}, function(cookies) {
            // const json = JSON.stringify(cookies, null, 2);
            chrome.runtime.sendMessage({action: "exportCookies_from_background", cookies: cookies});
        });
    }
});

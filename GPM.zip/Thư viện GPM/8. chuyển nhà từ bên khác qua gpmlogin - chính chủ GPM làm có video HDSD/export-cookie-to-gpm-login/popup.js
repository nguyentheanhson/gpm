document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('exportButton').addEventListener('click', exportCookies);
});

function exportCookies() {
    chrome.runtime.sendMessage({action: "exportCookies_from_popup"});
}

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === "exportCookies_from_background") {
        const json = JSON.stringify(message.cookies, null, 2);
        const blob = new Blob([json], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        chrome.downloads.download({
            url: url,
            filename: 'cookies.json'
        }, function(downloadId) {
            // Clean up
            URL.revokeObjectURL(url);
        });
    }
});
